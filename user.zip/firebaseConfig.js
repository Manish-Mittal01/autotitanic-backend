const firebaseConfig = {
  apiKey: "AIzaSyBbteKMos6_GSE9FlJmkGtRTSK55NQB--k",
  authDomain: "autotitanic-fde97.firebaseapp.com",
  projectId: "autotitanic-fde97",
  // storageBucket: "autotitanic-fde97.appspot.com",
  messagingSenderId: "679017205172",
  appId: "1:679017205172:web:b68f83d918ca7a8327f6e1",
  measurementId: "G-BZFNQW49GF",
  storageBucket: "gs://autotitanic-fde97.appspot.com",
};

module.exports.firebaseConfig = firebaseConfig;
